<template>
  <div class="hello">
      <p class="border-top pt-4 pb-4 mb-0">IPT</p>
  </div>
</template>

<script>
export default {
  name: 'Footer'
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
