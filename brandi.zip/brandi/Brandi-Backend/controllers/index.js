module.exports={
    "user":require("./user"),
    "client":require("./client"),
    "designacao_objetos": require("./designacao_objetos"),
    "role": require("./role")
}