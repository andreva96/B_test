var db = require('../models/db')

exports.listar = (req, res) => {
    db.Clientes.findAll().then(
        Clientes => res.status(200).json({
            "clientes": Clientes
        }),
        error => res = status(500).send(error.message)
    )
};

exports.adicionarcliente = (req, res) => {

    db.Clientes.create({
        email: req.query.email,
        nome: req.query.nome,
        nif: req.query.nif,
        morada: req.query.morada,
        contacto: req.query.contacto
    }
    )
    console.log("Dados Inseridos")
}

exports.updateClient = (req, res, next) => {
    db.Clientes.update({
        email: req.body.email,
        nome: req.body.nome,
        nif: req.body.nif,
        morada: req.body.morada,
        contacto: req.body.contacto
    }, {
            where: req.params.ClienteId
        }).then(
            (rowsUpdated) => {
                res.json(rowsUpdated)
            }
        ).catch(next)
}